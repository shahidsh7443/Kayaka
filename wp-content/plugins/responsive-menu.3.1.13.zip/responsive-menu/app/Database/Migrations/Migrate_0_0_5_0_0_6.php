<?php

namespace ResponsiveMenu\Database\Migrations;

class Migrate_0_0_5_0_0_6 extends Migrate {

    protected $migrations = [
        'moon' => 'baz'
    ];

}
